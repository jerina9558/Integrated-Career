const mongoose = require('mongoose');

const BudgetSchema = new mongoose.Schema({
  income: {
    type: Number,
    required: true,
  },
  split: {
    type: Map,
    of: Number,
    required: true,
  },
  date: {
    type: String,
    required: true,
  },
}, {
  timestamps: true,
});

module.exports = mongoose.model('Budget', BudgetSchema);
