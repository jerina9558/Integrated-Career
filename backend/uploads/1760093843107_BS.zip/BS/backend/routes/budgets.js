const express = require('express');
const router = express.Router();
const Budget = require('../models/Budget');

// POST: Save a budget
router.post('/', async (req, res) => {
  try {
    const { income, split, date } = req.body;
    const newBudget = new Budget({ income, split, date });
    const saved = await newBudget.save();
    res.status(201).json(saved);
  } catch (err) {
    res.status(500).json({ error: 'Failed to save budget' });
  }
});

// GET: Get all budgets
router.get('/', async (req, res) => {
  try {
    const budgets = await Budget.find().sort({ createdAt: -1 });
    res.json(budgets);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch budgets' });
  }
});

// DELETE: Delete a budget by ID
router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Budget.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ error: 'Budget not found' });
    res.json({ message: 'Budget deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete budget' });
  }
});
// **Update a budget by id** (PUT route)
router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const { income, split, date } = req.body;
  try {
    const updatedBudget = await Budget.findByIdAndUpdate(
      id,
      { income, split, date },
      { new: true }
    );
    if (!updatedBudget) {
      return res.status(404).json({ error: 'Budget not found' });
    }
    res.json(updatedBudget);
  } catch (err) {
    res.status(500).json({ error: 'Update failed' });
  }
});

module.exports = router;
