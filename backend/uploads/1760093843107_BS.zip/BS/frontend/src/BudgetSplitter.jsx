import React, { useState, useEffect } from "react";
import axios from "axios";

const API_URL = "http://localhost:5000/api/budgets";

export default function BudgetSplitter() {
  const [income, setIncome] = useState("");
  const [split, setSplit] = useState(null);
  const [savedBudgets, setSavedBudgets] = useState([]);
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState(null); // track editing budget id

  useEffect(() => {
    fetchBudgets();
  }, []);

  const fetchBudgets = async () => {
    try {
      setLoading(true);
      const res = await axios.get(API_URL);
      setSavedBudgets(res.data);
      setLoading(false);
    } catch (error) {
      alert("Failed to load budgets");
      setLoading(false);
    }
  };

  const calculateSplit = (incomeValue) => ({
    "Rent & Utilities": incomeValue * 0.3,
    "Food & Groceries": incomeValue * 0.2,
    Transportation: incomeValue * 0.1,
    "Savings & Investments": incomeValue * 0.3,
    Entertainment: incomeValue * 0.06,
    Others: incomeValue * 0.04,
  });

  const handleCalculate = () => {
    if (!income) return alert("Enter your income!");
    setSplit(calculateSplit(Number(income)));
  };

  const handleInputChange = (category, value) => {
    setSplit({ ...split, [category]: Number(value) });
  };

  const handleSave = async () => {
    if (!split) return alert("Calculate first!");
    try {
      if (editingId) {
        // Update existing budget
        await axios.put(`${API_URL}/${editingId}`, {
          income: Number(income),
          split: { ...split },
          date: new Date().toLocaleDateString(),
        });
        setEditingId(null);
      } else {
        // Save new budget
        await axios.post(API_URL, {
          income: Number(income),
          split: { ...split },
          date: new Date().toLocaleDateString(),
        });
      }
      setIncome("");
      setSplit(null);
      fetchBudgets();
    } catch (error) {
      alert("Failed to save budget");
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`${API_URL}/${id}`);
      fetchBudgets();
    } catch (error) {
      alert("Failed to delete budget");
    }
  };

  const handleEdit = (budget) => {
    console.log("Edit clicked:", budget); // debug log
    if (!budget) return alert("Invalid budget data");

    setIncome(budget.income.toString());
    setSplit(budget.split);
    setEditingId(budget._id);
  };

  const totalAllocated = split
    ? Object.values(split).reduce((a, b) => a + b, 0)
    : 0;

  // Debug logs for state changes
  console.log("income:", income);
  console.log("split:", split);
  console.log("editingId:", editingId);

  return (
    <div style={styles.page}>
      <div style={styles.container}>
        <h2 style={styles.title}>💰 Budget Splitter</h2>
        <p style={styles.subtitle}>
          Manage your monthly income with smart budget allocation
        </p>

        {/* Income Input */}
        <div style={styles.card}>
          <div style={styles.incomeSection}>
            <label style={styles.label}>Monthly Income</label>
            <input
              type="number"
              placeholder="Enter your monthly income"
              value={income}
              onChange={(e) => setIncome(e.target.value)}
              style={styles.input}
            />
          </div>
          <div style={styles.btnGroup}>
            <button onClick={handleCalculate} style={styles.btnCalculate}>
              Calculate
            </button>
            <button onClick={handleSave} style={styles.btnSave}>
              {editingId ? "Update" : "Save"}
            </button>
          </div>
        </div>

        {/* Budget Allocation */}
        {split && (
          <div style={styles.card}>
            <h3 style={styles.sectionTitle}>Your Budget Allocation</h3>
            <div style={styles.grid}>
              {Object.entries(split).map(([category, value]) => (
                <div key={category} style={styles.budgetCard}>
                  <label style={styles.categoryLabel}>{category}</label>
                  <input
                    type="number"
                    value={value}
                    onChange={(e) =>
                      handleInputChange(category, e.target.value)
                    }
                    style={styles.categoryInput}
                  />
                </div>
              ))}
            </div>
            <h4 style={styles.total}>
              Total Allocated: {totalAllocated.toLocaleString()}
            </h4>
          </div>
        )}

        {/* Saved Budgets */}
        <div style={styles.card}>
          <h3 style={styles.sectionTitle}>Saved Budgets</h3>
          {loading ? (
            <p>Loading...</p>
          ) : savedBudgets.length === 0 ? (
            <p>No saved budgets yet.</p>
          ) : (
            savedBudgets
              .slice()
              .reverse()
              .map((b) => (
                <div key={b._id} style={styles.savedCard}>
                  <div style={styles.savedHeader}>
                    <span>{b.date}</span>
                    <span style={{ fontWeight: "bold" }}>
                      Income: {b.income.toLocaleString()}
                    </span>
                  </div>
                  <div style={styles.grid}>
                    {Object.entries(b.split).map(([cat, val]) => (
                      <div key={cat} style={styles.budgetCard}>
                        <span style={styles.categoryLabel}>{cat}</span>
                        <span style={styles.savedAmount}>
                          {val.toLocaleString()}
                        </span>
                      </div>
                    ))}
                  </div>
                  <div style={styles.savedActions}>
                    <button
                      onClick={() => handleEdit(b)}
                      style={{ ...styles.btnDelete, background: "#1976d2" }}
                    >
                      ✏️ Edit
                    </button>
                    <button
                      onClick={() => handleDelete(b._id)}
                      style={styles.btnDelete}
                    >
                      ❌ Delete
                    </button>
                  </div>
                </div>
              ))
          )}
        </div>
      </div>
    </div>
  );
}

const styles = {
  page: {
    background: "#ffffff",
    minHeight: "100vh",
    display: "flex",
    justifyContent: "center",
    padding: "40px 20px",
  },
  container: {
    width: "100%",
    maxWidth: "900px",
    margin: "auto",
  },
  title: { fontSize: "2rem", fontWeight: "700", textAlign: "center" },
  subtitle: { textAlign: "center", color: "#555", marginBottom: "20px" },
  card: {
    background: "#fff",
    borderRadius: "15px",
    padding: "20px",
    marginBottom: "20px",
    boxShadow: "0 4px 15px rgba(0,0,0,0.1)",
  },
  incomeSection: { marginBottom: "10px" },
  label: { display: "block", marginBottom: "5px", fontWeight: "500" },
  input: {
    width: "100%",
    maxWidth: "300px",
    padding: "10px",
    borderRadius: "8px",
    border: "1px solid #ccc",
  },
  btnGroup: { marginTop: "10px", display: "flex", gap: "10px" },
  btnCalculate: {
    flex: 1,
    background: "#2e3a59",
    color: "#fff",
    border: "none",
    padding: "10px",
    borderRadius: "8px",
    cursor: "pointer",
  },
  btnSave: {
    flex: 1,
    background: "#2e7d32",
    color: "#fff",
    border: "none",
    padding: "10px",
    borderRadius: "8px",
    cursor: "pointer",
  },
  sectionTitle: { marginBottom: "15px" },
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))",
    gap: "15px",
  },
  budgetCard: {
    background: "#f1f5f9",
    borderRadius: "10px",
    padding: "10px",
    textAlign: "center",
  },
  categoryLabel: { fontWeight: "500", display: "block", marginBottom: "5px" },
  categoryInput: {
    width: "100%",
    maxWidth: "100px",
    padding: "5px",
    borderRadius: "6px",
    border: "1px solid #ccc",
  },
  total: { textAlign: "right", marginTop: "15px", fontWeight: "600" },
  savedCard: {
    background: "#f9fafb",
    borderRadius: "10px",
    padding: "15px",
    marginBottom: "15px",
  },
  savedHeader: {
    display: "flex",
    justifyContent: "space-between",
    marginBottom: "10px",
    fontSize: "0.9rem",
    color: "#555",
  },
  savedAmount: { fontWeight: "600" },
  savedActions: {
    textAlign: "right",
    marginTop: "10px",
    display: "flex",
    gap: "10px",
    justifyContent: "flex-end",
  },
  btnDelete: {
    background: "#e53935",
    color: "#fff",
    border: "none",
    padding: "5px 10px",
    borderRadius: "6px",
    cursor: "pointer",
  },
};
