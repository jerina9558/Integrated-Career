import React from "react";
import BudgetSplitter from "./BudgetSplitter";
import "./App.css";
import "./index.css";

function App() {
  return (
    <div>
      <BudgetSplitter />
    </div>
  );
}

export default App;
